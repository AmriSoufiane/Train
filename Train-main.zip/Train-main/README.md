## Train
* A small application to book ticket for travelling in train
* 2 files
* Train.cs where are the class
* Program.cs call to class
